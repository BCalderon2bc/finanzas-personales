import '../../widgets/bank_brand.dart' show bankKey;
import '../../data/card_spending.dart';
import '../../data/exchange_rate.dart';
import '../../core/app_theme.dart'
    show appBorder, appMuted, appSurfaceMuted, primaryColor;
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'dashboard_overview.dart';

Color get _blue => primaryColor;
const _green = Color(0xFF397455);
const _red = Color(0xFFB13D32);
const _amber = Color(0xFF946200);
Color get _muted => appMuted;
Color get _border => appBorder;

class DashboardFinancialHealth extends StatelessWidget {
  const DashboardFinancialHealth({
    super.key,
    required this.data,
    required this.currency,
    this.trailingChart,
  });

  final Widget? trailingChart;
  final DashboardOverview data;
  final String currency;

  String money(int value) => dashboardMoney(value, currency);

  @override
  Widget build(BuildContext context) {
    final c = data.currencies[currency]!;
    final debt = c.liabilities;

    final savingsBalance = data.accounts
        .where(
          (a) =>
              a['currency'] == currency &&
              a['account_type'] == 'savings' &&
              a['is_active'] == true,
        )
        .fold<int>(0, (sum, a) => sum + (a['balance_cents'] as int));

    final savings = math.max(0, savingsBalance);

    final positiveCategories =
        c.categories.entries.where((e) => e.value > 0).toList()
          ..sort((a, b) => b.value.compareTo(a.value));

    final palette = [
      _blue,
      Color(0xFF796A9C),
      Color(0xFF4F8291),
      Color(0xFFA16E88),
      Color(0xFFAC8140),
      Color(0xFF94A3B8),
    ];

    final categorySlices = <_Slice>[];

    for (var i = 0; i < positiveCategories.length && i < 5; i++) {
      final entry = positiveCategories[i];
      categorySlices.add(
        _Slice(
          entry.key == 'none'
              ? 'Sin categoría'
              : data.categoryNames[entry.key] ?? 'Categoría no disponible',
          entry.value,
          palette[i],
        ),
      );
    }

    final otherCategories = positiveCategories
        .skip(5)
        .fold<int>(0, (sum, e) => sum + e.value);

    if (otherCategories > 0) {
      categorySlices.add(
        _Slice('Otras categorías', otherCategories, palette.last),
      );
    }

    final positiveCategoryTotal = positiveCategories.fold<int>(
      0,
      (sum, e) => sum + e.value,
    );

    final hasNegativeCategories = c.categories.values.any((value) => value < 0);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _blue.withAlpha(16),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(Icons.monitor_heart_outlined, color: _blue),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Así van tus finanzas',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${data.period.label} · $currency',
                    style: TextStyle(color: _muted, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _statusCard(
          c: c,
          debt: debt,
          savings: savings,
          savingsBalance: savingsBalance,
        ),
        const SizedBox(height: 16),
        LayoutBuilder(
          builder: (context, box) {
            final scaledWidth =
                box.maxWidth /
                (MediaQuery.textScalerOf(context).scale(14) / 14).clamp(
                  1.0,
                  1.8,
                );
            final columns = trailingChart != null && scaledWidth >= 780 ? 2 : 1;
            final width = (box.maxWidth - 16 * (columns - 1)) / columns;

            final panels = [
              _ChartPanel(
                title: '¿Dónde se va tu dinero?',
                subtitle: 'Distribución del gasto neto positivo',
                icon: Icons.donut_large_outlined,
                center: '${positiveCategories.length}',
                centerLabel: 'categorías',
                centerColor: _blue,
                slices: categorySlices,
                emptyText: 'Sin categorías con gasto neto positivo.',
                legend: categorySlices.map((slice) {
                  final percentage = positiveCategoryTotal == 0
                      ? 0.0
                      : slice.value / positiveCategoryTotal * 100;
                  return _Legend(
                    slice.label,
                    '${money(slice.value)} · ${percentage.toStringAsFixed(0)}%',
                    slice.color,
                  );
                }).toList(),
                footer: hasNegativeCategories
                    ? 'Las categorías con devoluciones netas negativas no '
                          'participan en este gráfico. Sí se incluyen en el gasto neto del período.'
                    : 'Incluye categorías con gasto neto positivo. '
                          'Los porcentajes corresponden a su suma.',
              ),
              if (trailingChart != null) trailingChart!,
            ];

            return Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                for (final (index, panel) in panels.indexed)
                  SizedBox(
                    width:
                        columns == 2 &&
                            panels.length.isOdd &&
                            index == panels.length - 1
                        ? box.maxWidth
                        : width,
                    child: panel,
                  ),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _statusCard({
    required DashboardCurrency c,
    required int? debt,
    required int savings,
    required int savingsBalance,
  }) {
    final hasMonthlyActivity = c.income != 0 || c.expense != 0;
    final alerts = <String>[];

    if (c.overdueCount > 0) {
      alerts.add(
        '${c.overdueCount} deudas tienen capital vencido: ${money(c.overdue)}.',
      );
    }

    if (c.todayCount > 0) {
      alerts.add('${c.todayCount} deudas vencen hoy: ${money(c.dueToday)}.');
    }

    if (c.cash < 0) {
      alerts.add('El saldo total de tus cuentas activas es negativo.');
    }

    if (savingsBalance < 0) {
      alerts.add('El saldo conjunto de tus cuentas de ahorro es negativo.');
    }

    if (!c.cardKnown) {
      alerts.add('Hay ajustes de tarjeta que requieren revisión.');
    }

    final deficit = hasMonthlyActivity && c.net < 0;
    final color = deficit || c.cash < 0 || c.overdueCount > 0
        ? _red
        : alerts.isNotEmpty
        ? _amber
        : hasMonthlyActivity
        ? _green
        : _blue;

    final title = deficit
        ? 'Tus gastos superan tus ingresos este período'
        : hasMonthlyActivity
        ? 'Tu período mantiene un resultado positivo o equilibrado'
        : 'Aún falta actividad para evaluar este período';

    final description = deficit
        ? 'La diferencia es de ${money(-c.net)}. '
              'Revisa las categorías con mayor gasto para identificar dónde ajustar.'
        : hasMonthlyActivity
        ? 'Ingresos menos gastos: ${money(c.net)}. '
              'Este resultado incluye los movimientos registrados del rango seleccionado.'
        : 'Al registrar ingresos y gastos podrás ver cómo evoluciona el período.';

    final savingsText = debt == null
        ? 'La comparación entre ahorro y deuda está pendiente de revisión.'
        : debt == 0
        ? 'No tienes deuda registrada en esta moneda.'
        : savings >= debt
        ? 'Tus ahorros registrados alcanzan para cubrir la deuda de esta moneda.'
        : 'Tus ahorros cubren ${(savings / debt * 100).toStringAsFixed(0)}% '
              'de la deuda registrada en esta moneda.';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color.withAlpha(10),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withAlpha(45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                color == _red
                    ? Icons.warning_amber_rounded
                    : Icons.insights_rounded,
                color: color,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(description, style: const TextStyle(height: 1.5)),
          const SizedBox(height: 8),
          Text(savingsText, style: const TextStyle(height: 1.5)),
          if (alerts.isNotEmpty) ...[
            const Divider(height: 24),
            for (final alert in alerts)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '• $alert',
                  style: TextStyle(color: color, height: 1.4),
                ),
              ),
          ],
        ],
      ),
    );
  }
}

class _Slice {
  const _Slice(this.label, this.value, this.color);

  final String label;
  final int value;
  final Color color;
}

class _Legend {
  const _Legend(this.label, this.value, this.color);

  final String label;
  final String value;
  final Color color;
}

class _ChartPanel extends StatelessWidget {
  const _ChartPanel({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.center,
    required this.centerLabel,
    required this.centerColor,
    required this.slices,
    required this.emptyText,
    required this.legend,
    required this.footer,
  });

  final String title, subtitle, center, centerLabel, emptyText, footer;
  final IconData icon;
  final Color centerColor;
  final List<_Slice> slices;
  final List<_Legend> legend;

  Widget compactPanel(BuildContext context) {
    final hasValues = slices.any((slice) => slice.value > 0);
    final chart = Semantics(
      label: '$title: $center $centerLabel',
      child: SizedBox(
        width: 110,
        height: 110,
        child: CustomPaint(
          painter: _DonutPainter(slices),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(21),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: SizedBox(
                  width: 68,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        center,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: centerColor,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        centerLabel,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: _muted, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
    final values = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: legend
          .map(
            (item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    margin: const EdgeInsets.only(top: 5),
                    decoration: BoxDecoration(
                      color: item.color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.label,
                          style: TextStyle(fontSize: 13, color: _muted),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          item.value,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
    );
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(icon, color: _blue, size: 21),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(subtitle, style: TextStyle(color: _muted, fontSize: 13)),
          const SizedBox(height: 16),
          LayoutBuilder(
            builder: (context, box) {
              if (box.maxWidth /
                      (MediaQuery.textScalerOf(context).scale(14) / 14).clamp(
                        1.0,
                        1.8,
                      ) <
                  510) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(child: chart),
                    const SizedBox(height: 12),
                    values,
                  ],
                );
              }
              return Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  chart,
                  const SizedBox(width: 16),
                  Expanded(child: values),
                ],
              );
            },
          ),
          if (!hasValues)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(
                emptyText,
                style: TextStyle(color: _muted, fontSize: 12),
              ),
            ),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: Text(
              'Cómo se calcula',
              style: TextStyle(fontSize: 13, color: _muted),
            ),
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(
                  footer,
                  style: TextStyle(color: _muted, fontSize: 13, height: 1.5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.sizeOf(context).width < 650 ||
        MediaQuery.textScalerOf(context).scale(14) > 17.5) {
      return compactPanel(context);
    }
    final hasValues = slices.any((slice) => slice.value > 0);

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(icon, color: _blue, size: 21),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: TextStyle(color: _muted, fontSize: 12, height: 1.4),
          ),
          const SizedBox(height: 24),
          Center(
            child: SizedBox(
              width: 180,
              height: 180,
              child: Semantics(
                label: '$title: $center $centerLabel',
                child: CustomPaint(
                  painter: _DonutPainter(slices),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(35),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              center,
                              style: TextStyle(
                                color: centerColor,
                                fontSize: 28,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            centerLabel,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: _muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (!hasValues) ...[
            const SizedBox(height: 14),
            Text(
              emptyText,
              textAlign: TextAlign.center,
              style: TextStyle(color: _muted, fontSize: 12),
            ),
          ],
          const SizedBox(height: 22),
          for (final item in legend)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 9,
                    height: 9,
                    margin: const EdgeInsets.only(top: 4),
                    decoration: BoxDecoration(
                      color: item.color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 5,
                    child: Text(
                      item.label,
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Flexible(
                    flex: 6,
                    child: Text(
                      item.value,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          const Divider(height: 26),
          Text(
            footer,
            style: TextStyle(color: _muted, fontSize: 11, height: 1.5),
          ),
        ],
      ),
    );
  }
}

class _DonutPainter extends CustomPainter {
  const _DonutPainter(this.slices);

  final List<_Slice> slices;

  @override
  void paint(Canvas canvas, Size size) {
    const stroke = 19.0;
    final radius = math.min(size.width, size.height) / 2 - stroke / 2;
    final center = Offset(size.width / 2, size.height / 2);
    final rect = Rect.fromCircle(center: center, radius: radius);

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.butt;

    paint.color = appSurfaceMuted;
    canvas.drawCircle(center, radius, paint);

    final positive = slices.where((slice) => slice.value > 0).toList();
    final total = positive.fold<int>(0, (sum, slice) => sum + slice.value);

    if (total == 0) {
      return;
    }

    var start = -math.pi / 2;

    for (final slice in positive) {
      final sweep = slice.value / total * math.pi * 2;
      final gap = positive.length > 1 ? math.min(0.035, sweep * 0.15) : 0.0;

      paint.color = slice.color;
      canvas.drawArc(rect, start + gap / 2, sweep - gap, false, paint);
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _DonutPainter oldDelegate) =>
      oldDelegate.slices != slices;
}

class CreditCardSpendingChart extends StatelessWidget {
  const CreditCardSpendingChart({
    super.key,
    required this.spending,
    required this.currency,
    this.exchangeRate,
  });

  final List<CardSpending> spending;
  final String currency;
  final ExchangeRate? exchangeRate;

  static const _red = Color(0xFFC5223A);
  static const _gold = Color(0xFFA66D00);
  static const _teal = Color(0xFF007B73);
  static const _cardBlue = Color(0xFF175DC0);
  static const _purple = Color(0xFF7641A7);
  static const _green = Color(0xFF477B22);
  static const _orange = Color(0xFFC04F19);
  static const _charcoal = Color(0xFF293241);
  static const _slate = Color(0xFF667687);

  static const _palette = [
    _purple,
    _teal,
    _cardBlue,
    _red,
    _gold,
    _charcoal,
    _green,
    _orange,
    _slate,
  ];

  Map<String, Color> _cardColors() {
    final cards = <String, CardSpending>{
      for (final part in spending) part.cardId: part,
    };
    final ids = cards.keys.toList()..sort();
    final colors = <String, Color>{};
    final used = <Color>{};

    // Give every card a chance to use its tier color before bank colors.
    for (final id in ids) {
      final tierColor = switch (cards[id]!.tier) {
        'gold' => _gold,
        'black' => _charcoal,
        'platinum' => _slate,
        'signature' => _purple,
        'infinite' => _cardBlue,
        _ => null,
      };
      if (tierColor != null && used.add(tierColor)) colors[id] = tierColor;
    }
    for (final id in ids.where((id) => !colors.containsKey(id))) {
      final bankColor = switch (bankKey(cards[id]!.bank)) {
        'bac' || 'atlantida' => _red,
        'lafise' || 'bfp' => _teal,
        'ficohsa' || 'bdf' => _cardBlue,
        'avanz' => _gold,
        'banpro' => _green,
        _ => null,
      };
      if (bankColor != null && used.add(bankColor)) colors[id] = bankColor;
    }

    final alternatives = _palette
        .where((color) => !used.contains(color))
        .iterator;
    for (final id in ids.where((id) => !colors.containsKey(id))) {
      if (alternatives.moveNext()) {
        colors[id] = alternatives.current;
        used.add(alternatives.current);
        continue;
      }

      // Extend the palette for wallets with more cards than base colors.
      var key = (colors.length * 0x9E3779) & 0xFFFFFF;
      var variant = Color(0xFF000000 | key);
      while (!used.add(variant)) {
        key = (key + 0x9E3779) & 0xFFFFFF;
        variant = Color(0xFF000000 | key);
      }
      colors[id] = variant;
    }
    return colors;
  }

  @override
  Widget build(BuildContext context) {
    final colors = _cardColors();
    final totals = <String, ({String label, int cents})>{};
    var usedGeneralRate = false;
    var omittedForeignSpending = false;
    for (final part in spending) {
      var cents = part.cents;
      if (part.currency != currency && cents != 0) {
        final rate = part.cardExchangeRate ?? exchangeRate;
        if (rate == null) {
          omittedForeignSpending = true;
          continue;
        }
        usedGeneralRate = usedGeneralRate || part.cardExchangeRate == null;
        cents = rate.convert(cents, part.currency, currency);
      }
      totals[part.cardId] = (
        label: part.label,
        cents: (totals[part.cardId]?.cents ?? 0) + cents,
      );
    }
    final sorted = totals.entries.toList()
      ..sort((a, b) {
        final byAmount = b.value.cents.compareTo(a.value.cents);
        return byAmount == 0 ? a.key.compareTo(b.key) : byAmount;
      });
    final slices = [
      for (final item in sorted)
        _Slice(item.value.label, item.value.cents, colors[item.key]!),
    ];
    final total = slices
        .where((slice) => slice.value > 0)
        .fold<int>(0, (sum, slice) => sum + slice.value);
    return _ChartPanel(
      title: 'Gasto por tarjeta de crédito',
      subtitle: 'Gasto neto positivo · $currency',
      icon: Icons.credit_card_outlined,
      center: '${slices.length}',
      centerLabel: slices.length == 1 ? 'tarjeta' : 'tarjetas',
      centerColor: _blue,
      slices: slices,
      emptyText: 'Sin tarjetas con gasto neto positivo en el período.',
      legend: [
        for (final slice in slices)
          _Legend(
            slice.label,
            '${dashboardMoney(slice.value, currency)}'
            '${slice.value > 0 ? ' · ${(100 * slice.value / total).toStringAsFixed(0)}%' : ''}',
            slice.color,
          ),
      ],
      footer: [
        'Solo los gastos netos positivos forman parte de la dona. Los pagos de tarjeta quedan fuera del gasto.',
        'La conversión usa la tasa configurada en cada tarjeta.',
        if (usedGeneralRate)
          'Para tarjetas sin tasa propia se usó la tasa general.',
        if (omittedForeignSpending)
          'Los gastos en otra moneda sin una tasa disponible quedaron fuera del cálculo.',
      ].join(' '),
    );
  }
}
