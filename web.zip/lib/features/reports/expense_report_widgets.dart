import '../../core/app_theme.dart'
    show
        appBorder,
        appMuted,
        appPrimaryDeep,
        appSurfaceMuted,
        appSurfaceSubtle,
        appText,
        primaryColor;
import '../../data/exchange_rate.dart';
import '../credit_cards/credit_card_balances.dart'
    show cardPointsRedemption, cardPointsRedemptionLabel;
import 'package:flutter/material.dart';
import '../../utils/money.dart';
import '../../data/expense_report_categories.dart';

String expenseMoney(int cents, String currency) =>
    formatMoneyCents(cents, currency);

class ExpenseReportSummary extends StatelessWidget {
  const ExpenseReportSummary({
    super.key,
    required this.currency,
    required this.chargesCents,
    required this.refundsCents,
    required this.count,
    this.compact = false,
  });
  final String currency;
  final int chargesCents, refundsCents, count;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final total = chargesCents - refundsCents;

    Widget detail(String label, int amount) => Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(color: Colors.white.withAlpha(200), fontSize: 11),
          ),
          const SizedBox(height: 5),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              expenseMoney(amount, currency),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );

    return Container(
      padding: EdgeInsets.all(compact ? 16 : 22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: total < 0
              ? const [Color(0xFF3E6D66), Color(0xFF4B7B72)]
              : [appPrimaryDeep, primaryColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(
                Icons.pie_chart_outline_rounded,
                color: Colors.white,
                size: 21,
              ),
              const SizedBox(width: 9),
              const Expanded(
                child: Text(
                  'Gasto neto',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              Text(
                currency,
                style: TextStyle(
                  color: Colors.white.withAlpha(210),
                  fontSize: 11,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              expenseMoney(total, currency),
              style: TextStyle(
                color: Colors.white,
                fontSize: compact ? 27 : 34,
                letterSpacing: -0.8,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(height: 7),
          Text(
            '$count movimientos',
            style: TextStyle(color: Colors.white.withAlpha(210), fontSize: 12),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              detail('Cargos registrados', chargesCents),
              const SizedBox(width: 16),
              detail('Devoluciones', refundsCents),
            ],
          ),
        ],
      ),
    );
  }
}

class ExpenseCategoryCard extends StatelessWidget {
  const ExpenseCategoryCard({
    super.key,
    required this.name,
    required this.currency,
    required this.amountCents,
    required this.count,
    required this.positiveTotalCents,
    required this.color,
    required this.onTap,
    this.icon = Icons.category_outlined,
  });
  final String name, currency;
  final int amountCents, count, positiveTotalCents;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final refund = amountCents < 0;
    final accent = refund ? const Color(0xFF397455) : color;
    final ratio = amountCents > 0 && positiveTotalCents > 0
        ? amountCents / positiveTotalCents
        : 0.0;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: appBorder),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: accent.withAlpha(15),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Icon(icon, color: accent, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: TextStyle(
                            color: appText,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$count movimientos',
                          style: TextStyle(color: appMuted, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded, color: appMuted, size: 20),
                ],
              ),
              const SizedBox(height: 16),
              Wrap(
                alignment: WrapAlignment.spaceBetween,
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 12,
                runSpacing: 8,
                children: [
                  Text(
                    expenseMoney(amountCents, currency),
                    style: TextStyle(
                      color: accent,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: accent.withAlpha(14),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      refund
                          ? 'Devoluciones netas'
                          : '${(ratio * 100).toStringAsFixed(1)}%',
                      style: TextStyle(
                        color: accent,
                        fontWeight: FontWeight.w600,
                        fontSize: 11,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: ratio.clamp(0.0, 1.0).toDouble(),
                  minHeight: 7,
                  color: accent,
                  backgroundColor: appSurfaceMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

int expenseReportAmount(
  Map<String, dynamic> transaction,
  String currency,
  ExchangeRate? exchangeRate,
) {
  final amount = moneyCents(transaction['amount']);
  return exchangeRate?.convert(
        amount,
        transaction['currency'] as String,
        currency,
      ) ??
      amount;
}

class ExpenseDetailTile extends StatelessWidget {
  const ExpenseDetailTile({
    super.key,
    required this.transaction,
    required this.currency,
    this.exchangeRate,
  });
  final Map<String, dynamic> transaction;
  final String currency;
  final ExchangeRate? exchangeRate;

  @override
  Widget build(BuildContext context) {
    final tx = transaction;
    final card = tx['source'] == 'credit_card';
    final debt = tx['source'] == 'debt_payment';
    final originalCurrency = tx['currency'] as String;
    final originalAmount = moneyCents(tx['amount']);
    final amount = expenseReportAmount(tx, currency, exchangeRate);
    final refund = originalAmount < 0;
    String component(int cents) => expenseMoney(
      exchangeRate?.convert(cents, originalCurrency, currency) ?? cents,
      currency,
    );
    final color = refund ? const Color(0xFF397455) : primaryColor;
    final description = tx['description']?.toString().trim() ?? '';
    final reference = tx['reference']?.toString().trim() ?? '';
    final cardLabel = tx['card_label']?.toString().trim() ?? '';
    final date = DateTime.tryParse('${tx['transaction_date']}')?.toLocal();
    final dateText = date == null
        ? 'Fecha no disponible'
        : '${date.day.toString().padLeft(2, '0')}/'
              '${date.month.toString().padLeft(2, '0')}/${date.year}';
    const cardTypes = {
      'purchase': 'Compra',
      'interest': 'Intereses',
      'fee': 'Comisión',
      'refund': 'Devolución',
    };
    final insurance = debt ? moneyCents(tx['insurance_amount'] ?? 0) : 0;
    final otherFees = debt ? moneyCents(tx['fee_amount']) - insurance : 0;
    final label = debt
        ? 'Abono de deuda'
        : isCardInsuranceExpense(tx)
        ? 'Seguro de tarjeta'
        : card && tx['charge_kind'] == cardPointsRedemption
        ? cardPointsRedemptionLabel
        : card
        ? cardTypes[tx['card_transaction_type']] ?? 'Tarjeta'
        : 'Gasto de cuenta';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: appSurfaceSubtle,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            refund
                ? Icons.undo_rounded
                : debt
                ? Icons.payments_outlined
                : card
                ? Icons.credit_card_outlined
                : Icons.account_balance_wallet_outlined,
            color: color,
            size: 22,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  description.isEmpty ? label : description,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 5),
                Text(
                  '$dateText · $label',
                  style: TextStyle(color: appMuted, fontSize: 12),
                ),
                if (card && cardLabel.isNotEmpty)
                  Text(
                    cardLabel,
                    style: TextStyle(color: appMuted, fontSize: 12),
                  ),
                const SizedBox(height: 9),
                Text(
                  expenseMoney(amount, currency),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
                if (originalCurrency != currency)
                  Text(
                    'Original · ${expenseMoney(originalAmount, originalCurrency)}',
                    style: const TextStyle(fontSize: 12),
                  ),
                if (debt) ...[
                  const SizedBox(height: 7),
                  Text(
                    'Capital: ${component(moneyCents(tx['principal_amount']))}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  Text(
                    'Intereses: ${component(moneyCents(tx['interest_amount']))}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  if (insurance != 0)
                    Text(
                      'Seguro: ${component(insurance)}',
                      style: const TextStyle(fontSize: 12),
                    ),
                  if (otherFees != 0)
                    Text(
                      'Comisiones y otros cargos: ${component(otherFees)}',
                      style: const TextStyle(fontSize: 12),
                    ),
                ],
                if (reference.isNotEmpty) ...[
                  const SizedBox(height: 7),
                  SelectableText(
                    'Referencia: $reference',
                    style: TextStyle(color: appMuted, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
