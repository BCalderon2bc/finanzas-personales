import '../core/appearance.dart';
import 'dart:typed_data';
import 'package:excel/excel.dart' as x;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../utils/money.dart';
import 'export_report_models.dart';
import 'person_account_export_report.dart';

Uint8List reportExcel(ExportReport report) {
  final excel = x.Excel.createExcel();
  final firstSheet = report.showTotalsSummary
      ? 'Resumen'
      : report.tables.firstOrNull?.name ?? 'Resumen';
  excel.rename(excel.getDefaultSheet()!, firstSheet);
  excel.setDefaultSheet(firstSheet);
  final summary = excel['Resumen'];
  final person = report is PersonAccountExportReport ? report : null;
  summary.appendRow([x.TextCellValue('Mi Billete · ${report.title}')]);
  summary.appendRow([x.TextCellValue(report.period)]);
  if (report.scopeLabel case final scope?) {
    summary.appendRow([x.TextCellValue(scope)]);
    final row = summary.maxRows - 1;
    final start = x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row);
    summary.merge(
      start,
      x.CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: row),
    );
    summary.cell(start).cellStyle = x.CellStyle(
      fontFamily: AppearanceController.instance.fontFamily,
      bold: true,
      textWrapping: x.TextWrapping.WrapText,
    );
    summary.setRowHeight(row, 48);
  }
  summary.appendRow([
    x.TextCellValue('Generado: ${report.generatedAt.toIso8601String()}'),
  ]);
  if (person != null) {
    void highlighted(String value, {int fontSize = 12, double height = 30}) {
      summary.appendRow([x.TextCellValue(value)]);
      final row = summary.maxRows - 1;
      summary.merge(
        x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row),
        x.CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: row),
      );
      summary
          .cell(x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row))
          .cellStyle = x.CellStyle(
        fontFamily: AppearanceController.instance.fontFamily,
        bold: true,
        fontSize: fontSize,
        textWrapping: x.TextWrapping.WrapText,
        fontColorHex: x.ExcelColor.fromHexString(
          AppearanceController.instance.palette.navigation
              .toARGB32()
              .toRadixString(16)
              .substring(2),
        ),
        backgroundColorHex: x.ExcelColor.fromHexString(
          AppearanceController.instance.palette.tint
              .toARGB32()
              .toRadixString(16)
              .substring(2),
        ),
      );
      summary.setRowHeight(row, height);
    }

    highlighted('QUIÉN LE DEBE A QUIÉN');
    highlighted(person.direction, fontSize: 18, height: 58);
    highlighted(person.paymentNioLabel, fontSize: 20, height: 38);
    highlighted(person.paymentUsdLabel, fontSize: 20, height: 38);
    highlighted(person.paymentRateLabel, height: 30);

    highlighted('Titular: ${person.ownerName}', height: 34);
    highlighted('Cuenta con: ${person.personName}', height: 34);

    summary.appendRow([]);
  }
  if (person == null && report.showTotalsSummary) {
    summary.appendRow([
      x.TextCellValue('Moneda'),
      x.TextCellValue('Concepto'),
      x.TextCellValue('Monto'),
    ]);
    for (final total in report.totals) {
      summary.appendRow([
        x.TextCellValue(total.currency),
        x.TextCellValue(total.label),
        x.DoubleCellValue(total.cents / 100),
      ]);
      if (person != null) {
        final row = summary.maxRows - 1;
        summary
            .cell(x.CellIndex.indexByColumnRow(columnIndex: 1, rowIndex: row))
            .cellStyle = x.CellStyle(
          fontFamily: AppearanceController.instance.fontFamily,
          textWrapping: x.TextWrapping.WrapText,
        );
        summary.setRowHeight(row, 34);
      }
      summary
          .cell(
            x.CellIndex.indexByColumnRow(
              columnIndex: 2,
              rowIndex: summary.maxRows - 1,
            ),
          )
          .cellStyle = x.CellStyle(
        fontFamily: AppearanceController.instance.fontFamily,
        numberFormat: x.NumFormat.custom(formatCode: '#,##0.00'),
      );
    }
    summary.appendRow([]);
    summary.appendRow([
      x.TextCellValue('SUMAS POR MONEDA'),
      x.TextCellValue('Córdobas C\$'),
      x.TextCellValue('Dólares \$'),
    ]);
    final labels = report.totals.map((t) => t.label).toSet();
    for (final label in labels) {
      final nio = report.totals
          .where((t) => t.label == label && t.currency == 'NIO')
          .firstOrNull;
      final usd = report.totals
          .where((t) => t.label == label && t.currency == 'USD')
          .firstOrNull;
      summary.appendRow([
        x.TextCellValue(label),
        nio == null ? null : x.DoubleCellValue(nio.cents / 100),
        usd == null ? null : x.DoubleCellValue(usd.cents / 100),
      ]);
      for (var col = 1; col <= 2; col++) {
        summary
            .cell(
              x.CellIndex.indexByColumnRow(
                columnIndex: col,
                rowIndex: summary.maxRows - 1,
              ),
            )
            .cellStyle = x.CellStyle(
          fontFamily: AppearanceController.instance.fontFamily,
          numberFormat: x.NumFormat.custom(formatCode: '#,##0.00'),
        );
      }
    }
    summary.appendRow([]);
  }
  for (final note in report.notes) {
    summary.appendRow([x.TextCellValue(note)]);
    final row = summary.maxRows - 1;
    summary.merge(
      x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row),
      x.CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: row),
    );
    summary
        .cell(x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: row))
        .cellStyle = x.CellStyle(
      fontFamily: AppearanceController.instance.fontFamily,
      textWrapping: x.TextWrapping.WrapText,
      fontSize: 11,
    );
    summary.setRowHeight(row, 52);
  }
  summary.merge(
    x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: 0),
    x.CellIndex.indexByColumnRow(columnIndex: 2, rowIndex: 0),
  );
  summary
      .cell(x.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: 0))
      .cellStyle = x.CellStyle(
    fontFamily: AppearanceController.instance.fontFamily,
    bold: true,
    fontSize: 18,
  );
  for (final table in report.tables) {
    final sheet = excel[table.name];
    sheet.appendRow(table.columns.map((c) => x.TextCellValue(c)).toList());
    final cardColumns = <int>{
      for (var col = 0; col < table.columns.length; col++)
        if (['Tarjeta', 'Tarjetas vinculadas'].contains(table.columns[col]))
          col,
    };
    for (var col = 0; col < table.columns.length; col++) {
      sheet.setColumnWidth(
        col,
        cardColumns.contains(col)
            ? 54
            : table.columns[col] == 'Descripción'
            ? 45
            : table.columns[col] == 'Quién debe después'
            ? 48
            : table.columns[col] == 'Movimiento' ||
                  table.columns[col] == 'Tipo / signo'
            ? 32
            : 24,
      );
      sheet
          .cell(x.CellIndex.indexByColumnRow(columnIndex: col, rowIndex: 0))
          .cellStyle = x.CellStyle(
        fontFamily: AppearanceController.instance.fontFamily,
        bold: true,
        fontColorHex: x.ExcelColor.white,
        backgroundColorHex: x.ExcelColor.fromHexString(
          AppearanceController.instance.palette.primary
              .toARGB32()
              .toRadixString(16)
              .substring(2),
        ),
      );
    }
    for (final row in _exportTableRows(table, person != null)) {
      sheet.appendRow(
        row
            .map<x.CellValue?>(
              (v) => switch (v) {
                MoneyCell(:final cents) => x.DoubleCellValue(cents / 100),
                int n => x.IntCellValue(n),
                double n => x.DoubleCellValue(n),
                _ => x.TextCellValue(v?.toString() ?? ''),
              },
            )
            .toList(),
      );
      for (var column = 0; column < row.length; column++) {
        sheet
            .cell(
              x.CellIndex.indexByColumnRow(
                columnIndex: column,
                rowIndex: sheet.maxRows - 1,
              ),
            )
            .cellStyle = x.CellStyle(
          fontFamily: AppearanceController.instance.fontFamily,
        );
      }
      if (cardColumns.isNotEmpty) {
        var lineCount = 1;
        for (final col in cardColumns) {
          final text = reportCellText(row[col]);
          final lines = text
              .split('\n')
              .fold<int>(
                0,
                (n, line) =>
                    n + ((line.length + 47) ~/ 48).clamp(1, 30).toInt(),
              );
          if (lines > lineCount) lineCount = lines;
          sheet
              .cell(
                x.CellIndex.indexByColumnRow(
                  columnIndex: col,
                  rowIndex: sheet.maxRows - 1,
                ),
              )
              .cellStyle = x.CellStyle(
            fontFamily: AppearanceController.instance.fontFamily,
            textWrapping: x.TextWrapping.WrapText,
          );
        }
        if (lineCount > 1) {
          sheet.setRowHeight(
            sheet.maxRows - 1,
            (lineCount * 16.0).clamp(32.0, 400.0).toDouble(),
          );
        }
      }
      if (person != null) {
        for (var col = 0; col < row.length; col++) {
          if (row[col] is! MoneyCell) {
            sheet
                .cell(
                  x.CellIndex.indexByColumnRow(
                    columnIndex: col,
                    rowIndex: sheet.maxRows - 1,
                  ),
                )
                .cellStyle = x.CellStyle(
              fontFamily: AppearanceController.instance.fontFamily,
              textWrapping: x.TextWrapping.WrapText,
            );
          }
        }
        var lines = 1;
        for (var col = 0; col < row.length; col++) {
          final capacity = table.columns[col] == 'Descripción'
              ? 42
              : table.columns[col] == 'Quién debe después'
              ? 45
              : table.columns[col] == 'Movimiento'
              ? 29
              : 21;
          final needed = reportCellText(row[col])
              .split('\n')
              .fold<int>(
                0,
                (n, line) =>
                    n +
                    ((line.runes.length + capacity - 1) ~/ capacity)
                        .clamp(1, 1000)
                        .toInt(),
              );
          if (needed > lines) lines = needed;
        }
        sheet.setRowHeight(
          sheet.maxRows - 1,
          (lines * 14.0 + 10).clamp(52, 400).toDouble(),
        );
      }
      for (var col = 0; col < row.length; col++) {
        if (row[col] is MoneyCell) {
          sheet
              .cell(
                x.CellIndex.indexByColumnRow(
                  columnIndex: col,
                  rowIndex: sheet.maxRows - 1,
                ),
              )
              .cellStyle = x.CellStyle(
            fontFamily: AppearanceController.instance.fontFamily,
            numberFormat: x.NumFormat.custom(formatCode: '#,##0.00'),
          );
        }
      }
    }
  }
  summary.setColumnWidth(0, 25);
  summary.setColumnWidth(1, 60);
  summary.setColumnWidth(2, 24);
  final bytes = excel.encode();
  if (bytes == null) {
    throw StateError('No se pudo crear el Excel.');
  }
  return Uint8List.fromList(bytes);
}

String reportCellText(Object? v) =>
    v is MoneyCell ? formatAmountCents(v.cents) : v?.toString() ?? '';
List<List<String>> _pdfRows(List<List<Object?>> rows) {
  final output = <List<String>>[];
  for (final row in rows) {
    final chunks = row.map((v) {
      final codes = reportCellText(v).runes.toList();
      if (codes.isEmpty) {
        return <String>[''];
      }
      return [
        for (var n = 0; n < codes.length; n += 220)
          String.fromCharCodes(
            codes.sublist(n, (n + 220).clamp(0, codes.length).toInt()),
          ),
      ];
    }).toList();
    final count = chunks.fold<int>(1, (n, c) => c.length > n ? c.length : n);
    for (var index = 0; index < count; index++) {
      output.add(chunks.map((c) => index < c.length ? c[index] : '').toList());
    }
  }
  return output;
}

Future<Uint8List> reportPdf(
  ExportReport report, {
  required ByteData regularFont,
  required ByteData boldFont,
  Uint8List? logo,
}) async {
  if (report.rowCount > 5000) {
    throw StateError(
      'Para PDF usa un período menor: hay más de 5,000 filas. Excel conserva el detalle completo.',
    );
  }
  final person = report is PersonAccountExportReport ? report : null;
  final pdf = pw.Document(
    title: 'Mi Billete · ${report.title}',
    author: 'Mi Billete',
  );
  final theme = pw.ThemeData.withFont(
    base: pw.Font.ttf(regularFont),
    bold: pw.Font.ttf(boldFont),
  );
  pdf.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4.landscape,
      margin: pw.EdgeInsets.all(person == null ? 28 : 24),
      theme: theme,
      maxPages: 1000,
      header: (c) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          if (logo != null)
            pw.SizedBox(
              width: 150,
              height: 45,
              child: pw.Image(pw.MemoryImage(logo), fit: pw.BoxFit.contain),
            )
          else
            pw.Text(
              'Mi Billete',
              style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
            ),
          pw.Text(
            report.title,
            style: pw.TextStyle(fontSize: 17, fontWeight: pw.FontWeight.bold),
          ),
          pw.Text(report.period, style: const pw.TextStyle(fontSize: 10)),
          if (report.scopeLabel case final scope?)
            pw.Text(
              scope,
              style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
            ),
          pw.SizedBox(height: 10),
        ],
      ),
      footer: (c) => pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Generado: ${reportDate(report.generatedAt)}',
            style: const pw.TextStyle(fontSize: 8),
          ),
          pw.Text(
            'Página ${c.pageNumber} de ${c.pagesCount}',
            style: const pw.TextStyle(fontSize: 8),
          ),
        ],
      ),
      build: (c) => [
        if (person != null) ...[
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
              color: PdfColor.fromInt(
                AppearanceController.instance.palette.tint.toARGB32(),
              ),
              borderRadius: pw.BorderRadius.circular(8),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'QUIÉN LE DEBE A QUIÉN',
                  style: pw.TextStyle(
                    fontSize: 10,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColor.fromInt(
                      AppearanceController.instance.palette.navigation
                          .toARGB32(),
                    ),
                  ),
                ),
                pw.SizedBox(height: 6),
                pw.Text(
                  person.direction,
                  style: pw.TextStyle(
                    fontSize: 17,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
                pw.SizedBox(height: 5),
                pw.Text(
                  person.paymentNioLabel,
                  style: pw.TextStyle(
                    fontSize: 17,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColor.fromInt(
                      AppearanceController.instance.palette.navigation
                          .toARGB32(),
                    ),
                  ),
                ),
                pw.SizedBox(height: 5),
                pw.Text(
                  person.paymentUsdLabel,
                  style: pw.TextStyle(
                    fontSize: 17,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColor.fromInt(
                      AppearanceController.instance.palette.navigation
                          .toARGB32(),
                    ),
                  ),
                ),
                pw.SizedBox(height: 5),
                pw.Text(
                  person.paymentRateLabel,
                  style: const pw.TextStyle(fontSize: 9),
                ),

                pw.SizedBox(height: 5),
                if (person.settled)
                  pw.Text(
                    'Titular: ${person.ownerName}  |  Cuenta con: ${person.personName}',
                    style: const pw.TextStyle(fontSize: 9),
                  ),
              ],
            ),
          ),
          pw.SizedBox(height: 12),
        ],
        if (person == null && report.showTotalsSummary)
          pw.TableHelper.fromTextArray(
            headers: ['Concepto', 'Córdobas C\$', 'Dólares \$'],
            data: [
              for (final label in report.totals.map((t) => t.label).toSet())
                [
                  label,
                  for (final c in ['NIO', 'USD']) _totalLabel(report, label, c),
                ],
            ],
            headerStyle: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              fontSize: 8,
            ),
            cellStyle: const pw.TextStyle(fontSize: 8),
            cellAlignments: {
              1: pw.Alignment.centerRight,
              2: pw.Alignment.centerRight,
            },
            border: pw.TableBorder.all(color: PdfColors.grey300, width: .4),
          ),
        pw.SizedBox(height: 10),
        for (final table in report.tables) ...[
          pw.Text(
            table.name,
            style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 6),
          if (table.rows.isEmpty && person == null)
            pw.Text('Sin registros.', style: const pw.TextStyle(fontSize: 9)),
          if (table.rows.isNotEmpty ||
              table.footerRows.isNotEmpty ||
              person != null)
            pw.TableHelper.fromTextArray(
              headers: table.columns,
              data: _pdfRows(_exportTableRows(table, person != null)),
              columnWidths: {
                for (var n = 0; n < table.columns.length; n++)
                  n: pw.FlexColumnWidth(
                    person != null
                        ? switch (table.columns[n]) {
                            'Fecha' => 1.5,
                            'Movimiento' => 2.7,
                            'Descripción' => 3.2,
                            'Moneda' => 1.1,
                            'Importe original' => 1.5,
                            'Tasa C\$/\$' => 1.4,
                            'Variación C\$' => 1.5,
                            'Saldo C\$' => 1.4,
                            'Quién debe después' => 3.0,
                            _ => 1.6,
                          }
                        : [
                            'Tarjeta',
                            'Tarjetas vinculadas',
                            'Descripción',
                          ].contains(table.columns[n])
                        ? 3.2
                        : table.columns[n] == 'Moneda'
                        ? 1.05
                        : table.columns[n] == 'Fecha'
                        ? 1.6
                        : 1.6,
                  ),
              },
              cellAlignments: {
                for (var n = 0; n < table.columns.length; n++)
                  if (table.rows.any((r) => r[n] is MoneyCell) ||
                      table.footerRows.any((r) => r[n] is MoneyCell))
                    n: pw.Alignment.centerRight,
              },
              headerStyle: pw.TextStyle(
                fontSize: table.columns.length >= 11
                    ? 7
                    : person == null
                    ? 8
                    : 7.5,
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.white,
              ),
              headerDecoration: pw.BoxDecoration(
                color: PdfColor.fromInt(
                  AppearanceController.instance.palette.primary.toARGB32(),
                ),
              ),
              cellStyle: pw.TextStyle(
                fontSize: table.columns.length >= 11
                    ? 7
                    : person == null
                    ? 8
                    : 7.5,
              ),
              cellPadding: const pw.EdgeInsets.all(5),
              border: pw.TableBorder.all(color: PdfColors.grey300, width: .4),
            ),
          pw.SizedBox(height: 12),
        ],
        for (final note in report.notes.skip(person == null ? 0 : 2))
          pw.Padding(
            padding: const pw.EdgeInsets.only(bottom: 4),
            child: pw.Text(
              note,
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
            ),
          ),
      ],
    ),
  );
  return pdf.save();
}

String _totalLabel(ExportReport report, String label, String currency) {
  final total = report.totals
      .where((t) => t.label == label && t.currency == currency)
      .firstOrNull;
  return total == null ? '—' : formatAmountCents(total.cents);
}

// Total al pie del detalle. Suma únicamente las columnas de importes visibles;
// la tasa no se suma y el saldo neto conserva su cálculo independiente.
List<List<Object?>> _exportTableRows(ReportTable table, bool person) {
  if (table.footerRows.isNotEmpty) return [...table.rows, ...table.footerRows];
  if (!person) return table.rows;
  final amountColumns = <int>[
    for (var i = 0; i < table.columns.length; i++)
      if (['Importe C\$', 'Importe original'].contains(table.columns[i])) i,
  ];
  if (amountColumns.isEmpty) return table.rows;
  final footer = List<Object?>.filled(table.columns.length, null);
  footer[0] = 'Total';
  for (final column in amountColumns) {
    var sum = 0;
    for (final row in table.rows) {
      final value = row[column];
      if (value is MoneyCell) sum += value.cents;
    }
    footer[column] = MoneyCell(sum);
  }
  return [...table.rows, footer];
}
