import '../core/supabase_client.dart';
import 'card_export_reports.dart';
import 'credit_card_additional_repository.dart';
import 'transaction_repository.dart';
import 'card_statement_repository.dart' show statementRows;
import 'debt_installment_repository.dart';
import 'export_report_models.dart';

Future<ExportReport> loadExportReport({
  required String kind,
  IncomeExpenseSelection selection = IncomeExpenseSelection.both,
  String? cardId,
  String? additionalCardFilter,
  String? accountId,
  required String currency,
  required DateTime start,
  required DateTime end,
  required DateTime month,
}) async {
  final uid = supabase.auth.currentUser?.id;
  if (uid == null) {
    throw StateError('Debes iniciar sesión.');
  }
  if (!['all', 'NIO', 'USD'].contains(currency) ||
      ![
        'movements',
        'consolidated_expenses',
        'debts',
        'budgets',
        'credit_cards',
        'credit_card_expenses',
        'accounts',
        'debit_cards',
      ].contains(kind)) {
    throw ArgumentError('Tipo de reporte o moneda inválidos.');
  }
  if (kind == 'credit_card_expenses') {
    final values = await Future.wait([
      statementRows('credit_cards', '*,financial_institutions(name)', uid),
      statementRows(
        'credit_card_transactions',
        '*,credit_card_additionals(holder_name,last_four)',
        uid,
      ),
      if (cardId != null && additionalCardFilter?.isNotEmpty == true)
        loadAdditionalCards(cardId, uid),
    ]);
    if (supabase.auth.currentUser?.id != uid) {
      throw StateError('La sesión cambió.');
    }
    return creditCardExpensesExport(
      cards: values[0],
      movements: values[1],
      start: start,
      end: end,
      generatedAt: DateTime.now(),
      currency: currency,
      cardId: cardId,
      additionalCardFilter: additionalCardFilter,
      additionalCard: values.length == 3
          ? values[2]
                .where((card) => card['id']?.toString() == additionalCardFilter)
                .firstOrNull
          : null,
    );
  }
  if (['credit_cards', 'debit_cards', 'accounts'].contains(kind)) {
    final credit = kind == 'credit_cards';
    final values = await Future.wait([
      statementRows(
        credit ? 'credit_cards' : 'debit_cards',
        kind == 'accounts' ? '*' : '*,financial_institutions(name)',
        uid,
      ),
      statementRows(
        'accounts',
        kind == 'debit_cards'
            ? 'id,name,currency,opening_balance,financial_institutions(name)'
            : 'id,name,currency,opening_balance',
        uid,
      ),
      loadUserTransactions(uid),
      statementRows(
        'credit_card_transactions',
        credit ? '*,credit_card_additionals(holder_name,last_four)' : '*',
        uid,
      ),
      statementRows('debt_payments', '*', uid),
    ]);
    if (supabase.auth.currentUser?.id != uid)
      throw StateError('La sesión cambió.');
    return credit
        ? creditCardsExport(
            cards: values[0],
            movements: values[3],
            start: start,
            end: end,
            generatedAt: DateTime.now(),
            currency: currency,
            cardId: cardId,
          )
        : debitCardsExport(
            cards: values[0],
            accounts: values[1],
            transactions: values[2],
            cardPayments: values[3]
                .where((p) => p['transaction_type'] == 'payment')
                .toList(),
            debtPayments: values[4],
            start: start,
            end: end,
            generatedAt: DateTime.now(),
            currency: currency,
            cardId: cardId,
            accountId: accountId,
            allAccounts: kind == 'accounts',
            selection: kind == 'accounts'
                ? selection
                : IncomeExpenseSelection.both,
          );
  }
  if (kind == 'debts') {
    final values = await Future.wait<Object>([
      statementRows(
        'debts',
        'id,description,creditor_name,currency,original_amount,status,due_date',
        uid,
      ),
      loadDebtInstallments(uid),
    ]);
    if (supabase.auth.currentUser?.id != uid) {
      throw StateError('La sesión cambió.');
    }
    final data = values[1] as DebtInstallmentData;
    return debtsReport(
      debts: values[0] as List<Map<String, dynamic>>,
      payments: data.payments,
      installments: data,
      currency: currency,
      generatedAt: DateTime.now(),
    );
  }
  final data = await loadIncomeExpenseData(
    includeBudgets: kind == 'budgets',
    userId: uid,
  );
  if (kind == 'consolidated_expenses') {
    return consolidatedExpensesReport(
      data.movements,
      start,
      end,
      currency,
      DateTime.now(),
    );
  }
  return kind == 'movements'
      ? movementsReport(
          data.movements,
          start,
          end,
          currency,
          DateTime.now(),
          selection: selection,
        )
      : budgetsReport(
          budgets: data.budgets,
          categories: data.categories,
          movements: data.movements,
          month: month,
          currency: currency,
          generatedAt: DateTime.now(),
        );
}

Future<
  ({
    List<ExportMovement> movements,
    List<Map<String, dynamic>> categories,
    List<Map<String, dynamic>> budgets,
  })
>
loadIncomeExpenseData({bool includeBudgets = false, String? userId}) async {
  final uid = userId ?? supabase.auth.currentUser?.id;
  if (uid == null || supabase.auth.currentUser?.id != uid) {
    throw StateError('Debes iniciar sesión.');
  }
  final values = await Future.wait([
    loadUserTransactions(uid),
    statementRows('accounts', 'id,name,currency', uid),
    statementRows('categories', 'id,name', uid),
    statementRows('credit_cards', 'id,name,currency', uid),
    statementRows(
      'credit_card_transactions',
      'id,credit_card_id,account_id,category_id,transaction_type,charge_kind,cash_advance_fee,amount,currency,transaction_date,description,reference,is_voided,is_receivable_funding,account_debit_amount,account_debit_currency,payment_exchange_rate',
      uid,
    ),
    statementRows('debts', 'id,description,currency', uid),
    statementRows(
      'debt_payments',
      'id,debt_id,account_id,principal_amount,interest_amount,fee_amount,insurance_amount,currency,payment_date,reference,is_voided',
      uid,
    ),
    if (includeBudgets)
      statementRows(
        'budgets',
        'id,category_id,currency,budget_amount,month,start_date,end_date',
        uid,
      ),
  ]);
  if (supabase.auth.currentUser?.id != uid) {
    throw StateError('La sesión cambió.');
  }
  final normalized = normalizeExportMovements(
    accountMovements: values[0],
    accounts: values[1],
    categories: values[2],
    cards: values[3],
    cardMovements: values[4],
    debts: values[5],
    debtPayments: values[6],
  );
  return (
    movements: normalized,
    categories: values[2],
    budgets: includeBudgets ? values[7] : <Map<String, dynamic>>[],
  );
}
