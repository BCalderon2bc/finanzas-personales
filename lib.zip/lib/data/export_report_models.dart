import '../utils/card_cash_advance.dart';
import '../features/credit_cards/credit_card_balances.dart'
    show
        cardMovementType,
        cardPointsRedemption,
        cardPointsRedemptionLabel,
        cardRebate,
        cardRebateLabel;
import 'period_logic.dart';
import '../utils/money.dart';
import 'card_statement_logic.dart';
import 'debt_installment_logic.dart';

class MoneyCell {
  const MoneyCell(this.cents, {this.isTotal = false});
  final int cents;
  final bool isTotal;
}

class ReportTable {
  const ReportTable(
    this.name,
    this.columns,
    this.rows, {
    this.footerRows = const [],
  });
  final String name;
  final List<String> columns;
  final List<List<Object?>> rows, footerRows;
}

class ReportTotal {
  const ReportTotal(this.currency, this.label, this.cents);
  final String currency, label;
  final int cents;
}

class ExportReport {
  const ExportReport({
    required this.title,
    required this.period,
    required this.generatedAt,
    required this.tables,
    required this.totals,
    required this.notes,
    this.showTotalsSummary = true,
    this.scopeLabel,
  });
  final String title, period;
  final String? scopeLabel;
  final DateTime generatedAt;
  final List<ReportTable> tables;
  final List<ReportTotal> totals;
  final List<String> notes;
  final bool showTotalsSummary;
  int get rowCount => tables.fold(0, (n, t) => n + t.rows.length);
}

class ExportMovement {
  const ExportMovement({
    required this.date,
    required this.values,
    required this.currency,
    required this.categoryId,
    required this.income,
    required this.expense,
    required this.unknown,
  });
  final DateTime date;
  final List<Object?> values;
  final String currency;
  final String? categoryId;
  final int income, expense;
  final bool unknown;
}

String reportDate(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
bool inReportRange(DateTime date, DateTime start, DateTime end) =>
    daysUntil(date, start) >= 0 && daysUntil(date, end) <= 0;
String _lookup(
  List<Map<String, dynamic>> rows,
  dynamic id,
  String key,
  String fallback,
) {
  for (final row in rows) {
    if ('${row['id']}' == '$id') {
      return row[key]?.toString() ?? fallback;
    }
  }
  return fallback;
}

List<ExportMovement> normalizeExportMovements({
  required List<Map<String, dynamic>> accountMovements,
  required List<Map<String, dynamic>> cardMovements,
  required List<Map<String, dynamic>> debtPayments,
  required List<Map<String, dynamic>> accounts,
  required List<Map<String, dynamic>> categories,
  required List<Map<String, dynamic>> cards,
  required List<Map<String, dynamic>> debts,
}) {
  final result = <ExportMovement>[];
  void add(
    Map<String, dynamic> row,
    String type,
    String account,
    int amount,
    int income,
    int expense, {
    bool unknown = false,
    String? description,
  }) {
    final date = DateTime.tryParse(
      '${row['transaction_date'] ?? row['payment_date']}',
    )?.toLocal();
    if (date == null) {
      throw FormatException('Hay un movimiento con fecha inválida.');
    }
    final currency = '${row['currency']}';
    if (!['NIO', 'USD'].contains(currency)) {
      throw StateError('Moneda no admitida: $currency');
    }
    final category = row['category_id']?.toString();
    result.add(
      ExportMovement(
        date: date,
        currency: currency,
        categoryId: category,
        income: income,
        expense: expense,
        unknown: unknown,
        values: [
          reportDate(date),
          type,
          account,
          _lookup(categories, category, 'name', 'Sin categoría'),
          description ?? row['description']?.toString() ?? '',
          currency,
          MoneyCell(amount),
          row['reference']?.toString() ?? '',
        ],
      ),
    );
  }

  const native = {
    'income': 'Ingreso',
    'expense': 'Gasto',
    'transfer': 'Transferencia',
    'deposit': 'Depósito',
    'withdrawal': 'Retiro',
  };
  for (final tx in accountMovements) {
    if (tx['is_voided'] == true) {
      continue;
    }
    final type = '${tx['transaction_type']}', amount = moneyCents(tx['amount']);
    var account = _lookup(
      accounts,
      tx['account_id'],
      'name',
      'Cuenta no disponible',
    );
    if (type == 'transfer') {
      account +=
          ' → ${_lookup(accounts, tx['destination_account_id'], 'name', 'Cuenta no disponible')}';
    }
    add(
      tx,
      tx['expense_kind'] == 'card_insurance'
          ? 'Seguro de tarjeta'
          : native[type] ?? 'Movimiento por revisar',
      account,
      amount,
      type == 'income' ? amount : 0,
      type == 'expense' ? amount : 0,
      unknown: !native.containsKey(type),
      description: tx['destination_amount'] == null
          ? null
          : '${tx['description'] ?? ''} · Recibido: ${formatMoneyCents(moneyCents(tx['destination_amount']), '${tx['destination_currency']}')} · Tasa C\$ ${tx['exchange_rate']} por \$1',
    );
  }
  const cardTypes = {
    cardCashAdvance: cardCashAdvanceLabel,
    'purchase': 'Compra con tarjeta',
    'refund': 'Devolución de tarjeta',
    'insurance': 'Seguro de tarjeta',
    cardPointsRedemption: cardPointsRedemptionLabel,
    cardRebate: cardRebateLabel,
    'interest': 'Intereses de tarjeta',
    'fee': 'Comisión de tarjeta',
    'payment': 'Pago de tarjeta',
  };
  for (final tx in cardMovements) {
    if (tx['is_voided'] == true) {
      continue;
    }
    final type = '${tx['transaction_type']}', amount = moneyCents(tx['amount']);
    final funding = tx['is_receivable_funding'] == true;
    final expense = funding || type == 'payment'
        ? 0
        : type == 'refund'
        ? -amount
        : isCardCashAdvance(tx)
        ? cardCashAdvanceFee(tx)
        : ['purchase', 'interest', 'fee'].contains(type)
        ? amount
        : 0;
    add(
      tx,
      funding
          ? 'Préstamo desde tarjeta'
          : cardTypes[cardMovementType(type, tx['charge_kind'])] ??
                'Ajuste de tarjeta por revisar',
      _lookup(cards, tx['credit_card_id'], 'name', 'Tarjeta no disponible'),
      type == 'refund' ? -amount : amount,
      0,
      expense,
      unknown: !cardTypes.containsKey(type),
      description: isCardCashAdvance(tx)
          ? '${tx['description'] ?? ''} · ${cardCashAdvanceBreakdown(tx)}'
          : type == 'payment' && tx['account_debit_amount'] != null
          ? '${tx['description'] ?? ''} · Débito de cuenta: ${formatMoneyCents(moneyCents(tx['account_debit_amount']), '${tx['account_debit_currency']}')}'
                '${tx['payment_exchange_rate'] == null ? '' : ' · Tasa C\$ ${tx['payment_exchange_rate']} por \$1'}'
          : null,
    );
  }
  for (final p in debtPayments) {
    if (p['is_voided'] == true) {
      continue;
    }
    final currency = '${p['currency']}';
    final capital = moneyCents(p['principal_amount']),
        interest = moneyCents(p['interest_amount']),
        fee = moneyCents(p['fee_amount']);
    final debt = _lookup(
      debts,
      p['debt_id'],
      'description',
      'Préstamo no disponible',
    );
    add(
      p,
      'Abono de préstamo',
      p['account_id'] == null
          ? 'Registro manual'
          : _lookup(accounts, p['account_id'], 'name', 'Cuenta no disponible'),
      capital + interest + fee,
      0,
      interest + fee,
      description:
          '$debt · Capital: ${formatMoneyCents(capital, currency)}; '
          'intereses: ${formatMoneyCents(interest, currency)}; seguro: ${formatMoneyCents(moneyCents(p['insurance_amount'] ?? 0), currency)}; otros cargos: ${formatMoneyCents(fee - moneyCents(p['insurance_amount'] ?? 0), currency)}',
    );
  }
  result.sort((a, b) => b.date.compareTo(a.date));
  return result;
}

enum IncomeExpenseSelection { both, income, expenses }

ExportReport movementsReport(
  List<ExportMovement> all,
  DateTime start,
  DateTime end,
  String currency,
  DateTime generatedAt, {
  IncomeExpenseSelection selection = IncomeExpenseSelection.both,
}) {
  final rows = all
      .where(
        (m) =>
            (currency == 'all' || m.currency == currency) &&
            inReportRange(m.date, start, end) &&
            ((selection != IncomeExpenseSelection.expenses && m.income != 0) ||
                (selection != IncomeExpenseSelection.income && m.expense != 0)),
      )
      .toList();
  final totals = <ReportTotal>[];
  for (final c in ['NIO', 'USD']) {
    if (currency != 'all' && currency != c) {
      continue;
    }
    final selected = rows.where((m) => m.currency == c);
    var income = 0, expense = 0;
    for (final row in selected) {
      income += row.income;
      expense += row.expense;
    }
    totals.addAll([
      if (selection != IncomeExpenseSelection.expenses)
        ReportTotal(c, 'Ingresos', income),
      if (selection != IncomeExpenseSelection.income)
        ReportTotal(c, 'Gasto neto', expense),
      if (selection == IncomeExpenseSelection.both)
        ReportTotal(c, 'Ingresos menos gastos', income - expense),
    ]);
  }
  rows.sort((a, b) => a.date.compareTo(b.date));
  return ExportReport(
    title: switch (selection) {
      IncomeExpenseSelection.both => 'Ingresos y gastos',
      IncomeExpenseSelection.income => 'Ingresos',
      IncomeExpenseSelection.expenses => 'Gastos',
    },
    period: '${reportDate(start)} al ${reportDate(end)}',
    generatedAt: generatedAt,
    tables: [
      ReportTable(
        'Detalle',
        const [
          'Fecha',
          'Tipo',
          'Cuenta / tarjeta',
          'Categoría',
          'Descripción',
          'Moneda',
          'Monto',
          'Referencia',
        ],
        [
          for (final row in rows)
            [
              ...row.values.take(6),
              MoneyCell(switch (selection) {
                IncomeExpenseSelection.both => row.income + row.expense,
                IncomeExpenseSelection.income => row.income,
                IncomeExpenseSelection.expenses => row.expense,
              }),
              row.values[7],
            ],
        ],
      ),
    ],
    totals: totals,
    notes: [
      'Los totales separan NIO y USD; no se convierten ni se suman monedas diferentes.',
      'Pagos de tarjeta y capital de préstamos no se vuelven a contar como gasto. Los intereses y comisiones pagados sí se incluyen. Las transferencias y préstamos por cobrar no se consideran ingresos o gastos personales.',
    ],
  );
}

/// Uses the same normalized source as movements, excluding linked account
/// entries in the repository so a loan payment appears only once.
ExportReport consolidatedExpensesReport(
  List<ExportMovement> all,
  DateTime start,
  DateTime end,
  String currency,
  DateTime generatedAt,
) {
  final expenses = movementsReport(
    all,
    start,
    end,
    currency,
    generatedAt,
    selection: IncomeExpenseSelection.expenses,
  );
  final capital = all
      .where(
        (m) =>
            m.values[1] == 'Abono de préstamo' &&
            (currency == 'all' || m.currency == currency) &&
            inReportRange(m.date, start, end),
      )
      .toList();
  int principal(ExportMovement m) =>
      (m.values[6] as MoneyCell).cents - m.expense;
  return ExportReport(
    title: 'Gastos consolidados',
    period: expenses.period,
    generatedAt: generatedAt,
    tables: [
      ...expenses.tables,
      if (capital.isNotEmpty)
        ReportTable(
          'Capital de cuotas y préstamos',
          const ['Fecha', 'Cuenta', 'Detalle', 'Moneda', 'Capital pagado'],
          [
            for (final m in capital)
              [
                m.values[0],
                m.values[2],
                m.values[4],
                m.currency,
                MoneyCell(principal(m)),
              ],
          ],
        ),
    ],
    totals: [
      for (final c in ['USD', 'NIO'])
        if (currency == 'all' || currency == c) ...[
          ReportTotal(
            c,
            'Gasto neto total',
            expenses.totals
                .where((t) => t.currency == c)
                .fold(0, (n, t) => n + t.cents),
          ),
          ReportTotal(
            c,
            'Capital de cuotas y préstamos (separado)',
            capital
                .where((m) => m.currency == c)
                .fold(0, (n, m) => n + principal(m)),
          ),
        ],
    ],
    notes: [
      ...expenses.notes,
      'Incluye gastos de cuentas y efectivo, compras de todas las tarjetas, cargos, seguros e intereses; las devoluciones restan. Los movimientos anulados se excluyen.',
      'Los pagos de tarjeta no se suman: la compra ya se contó en su fecha. Las compras financiadas se cuentan al registrarlas; sus pagos no vuelven a sumarse.',
      'El capital pagado de cuotas y préstamos se muestra separado del gasto. Sus intereses y cargos sí forman parte del gasto neto.',
      'Los gastos fijos previstos y ajustes del mes no son movimientos reales y no se suman. Registra su pago una sola vez en Movimientos.',
      'No se detectan duplicados ingresados manualmente como registros independientes: usa los pagos y vínculos de la aplicación.',
    ],
  );
}

ExportReport debtsReport({
  required List<Map<String, dynamic>> debts,
  required List<Map<String, dynamic>> payments,
  required DebtInstallmentData installments,
  required String currency,
  required DateTime generatedAt,
}) {
  final rows = <List<Object?>>[], quotas = <List<Object?>>[];
  final totals = <ReportTotal>[];
  final sums = <String, int>{'NIO': 0, 'USD': 0};
  const status = {
    'active': 'Activa',
    'overdue': 'Vencida',
    'paused': 'Pausada',
    'paid': 'Pagada',
    'cancelled': 'Cancelada',
  };
  for (final debt in debts) {
    if (currency != 'all' && debt['currency'] != currency) {
      continue;
    }
    final c = '${debt['currency']}';
    var paid = 0;
    for (final p in payments) {
      if ('${p['debt_id']}' == '${debt['id']}' && p['is_voided'] != true) {
        if (p['currency'] != c) {
          throw StateError('Un abono tiene moneda diferente al préstamo.');
        }
        paid += moneyCents(p['principal_amount']);
      }
    }
    final original = moneyCents(debt['original_amount']),
        pending = debt['status'] == 'paid' ? 0 : original - paid;
    if (pending < 0) {
      throw StateError('Los abonos superan el capital de un préstamo.');
    }
    if (debt['status'] != 'cancelled') {
      sums[c] = (sums[c] ?? 0) + pending;
    }
    rows.add([
      debt['description'] ?? '',
      debt['creditor_name'] ?? '',
      c,
      MoneyCell(original, isTotal: true),
      MoneyCell(paid, isTotal: true),
      MoneyCell(pending, isTotal: true),
      status[debt['status']] ?? '${debt['status']}',
      debt['due_date'] == null
          ? 'Sin fecha'
          : shortStatementDate(debt['due_date']),
    ]);
    for (final i in installments.currentFor('${debt['id']}')) {
      final p = installments.progress(i);
      quotas.add([
        debt['description'] ?? '',
        i['number'],
        shortStatementDate(i['due_date']),
        c,
        MoneyCell(moneyCents(i['amount'])),
        MoneyCell(p.paid, isTotal: true),
        p.remaining == null
            ? 'Por revisar'
            : MoneyCell(p.remaining!, isTotal: true),
        p.settled ? 'Cubierta' : 'Pendiente',
      ]);
    }
  }
  for (final c in ['NIO', 'USD']) {
    if (currency == 'all' || currency == c) {
      totals.add(
        ReportTotal(c, 'Capital pendiente no cancelado', sums[c] ?? 0),
      );
    }
  }
  return ExportReport(
    title: 'Deudas y cuotas',
    period: 'Saldos actuales al ${reportDate(generatedAt)}',
    generatedAt: generatedAt,
    tables: [
      ReportTable('Prestamos', const [
        'Préstamo',
        'Acreedor',
        'Moneda',
        'Capital original',
        'Abonado a capital',
        'Capital pendiente',
        'Estado',
        'Vencimiento',
      ], rows),
      ReportTable('Cuotas', const [
        'Préstamo',
        'Cuota',
        'Vencimiento',
        'Moneda',
        'Programado',
        'Abonado',
        'Pendiente',
        'Estado',
      ], quotas),
      ReportTable(
        'Desglose de abonos',
        const [
          'Fecha',
          'Préstamo',
          'Moneda',
          'Capital',
          'Intereses',
          'Seguro',
          'Otros cargos',
          'Total',
        ],
        [
          for (final p in payments)
            if (p['is_voided'] != true &&
                (currency == 'all' || p['currency'] == currency))
              [
                shortStatementDate(p['payment_date']),
                _lookup(
                  debts,
                  p['debt_id'],
                  'description',
                  'Préstamo no disponible',
                ),
                '${p['currency']}',
                MoneyCell(moneyCents(p['principal_amount'])),
                MoneyCell(moneyCents(p['interest_amount'])),
                MoneyCell(moneyCents(p['insurance_amount'] ?? 0)),
                MoneyCell(
                  moneyCents(p['fee_amount']) -
                      moneyCents(p['insurance_amount'] ?? 0),
                ),
                MoneyCell(debtPaymentTotalCents(p), isTotal: true),
              ],
        ],
      ),
    ],
    totals: totals,
    notes: const [
      'Los saldos son actuales, no una reconstrucción histórica. Las deudas canceladas se muestran pero no integran el total pendiente.',
      'Las cuotas son pagos programados y pueden incluir intereses, seguro y otros cargos; no se suman de nuevo al capital pendiente. Si un préstamo figura pagado con capital restante, revisa su historial.',
    ],
  );
}

ExportReport budgetsReport({
  required List<Map<String, dynamic>> budgets,
  required List<Map<String, dynamic>> categories,
  required List<ExportMovement> movements,
  required DateTime month,
  required String currency,
  required DateTime generatedAt,
}) {
  final rows = <List<Object?>>[], totals = <ReportTotal>[];
  final limits = <String, int>{}, expenses = <String, int>{};
  final counted = <String>{};
  for (final b in budgets) {
    final from = budgetStart(b), until = budgetEnd(b);
    if (until.isBefore(DateTime(month.year, month.month)) ||
        from.isAfter(DateTime(month.year, month.month + 1, 0)) ||
        (currency != 'all' && b['currency'] != currency)) {
      continue;
    }
    final c = '${b['currency']}',
        limit = moneyCents(b['budget_amount']),
        spent = movements
            .where(
              (m) =>
                  m.categoryId == b['category_id'] &&
                  m.currency == c &&
                  includesDay(m.date, from, until),
            )
            .fold<int>(0, (total, m) => total + m.expense);
    limits[c] = (limits[c] ?? 0) + limit;
    if (counted.add('${b['id']}')) {
      expenses[c] = (expenses[c] ?? 0) + spent;
    }
    rows.add([
      _lookup(categories, b['category_id'], 'name', 'Categoría no disponible'),
      '${reportDate(from)} al ${reportDate(until)}',
      c,
      MoneyCell(limit, isTotal: true),
      MoneyCell(spent, isTotal: true),
      MoneyCell(limit - spent, isTotal: true),
      spent > limit ? 'Excedido' : 'Dentro del límite',
    ]);
  }
  for (final c in ['NIO', 'USD']) {
    if (currency == 'all' || currency == c) {
      totals.addAll([
        ReportTotal(c, 'Presupuestado', limits[c] ?? 0),
        ReportTotal(c, 'Gasto de categorías presupuestadas', expenses[c] ?? 0),
        ReportTotal(
          c,
          'Disponible neto',
          (limits[c] ?? 0) - (expenses[c] ?? 0),
        ),
      ]);
    }
  }
  return ExportReport(
    title: 'Presupuestos',
    period: '${month.month.toString().padLeft(2, '0')}/${month.year}',
    generatedAt: generatedAt,
    tables: [
      ReportTable('Presupuestos', const [
        'Categoría',
        'Período',
        'Moneda',
        'Límite',
        'Gasto neto',
        'Disponible',
        'Estado',
      ], rows),
    ],
    totals: totals,
    notes: const [
      'Incluye presupuestos que coinciden con el mes seleccionado. El gasto de cada presupuesto corresponde a todas sus fechas. Descuenta devoluciones. Importes originales, sin conversión de monedas.',
    ],
  );
}
